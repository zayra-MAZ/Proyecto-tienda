
package Tienda;

import java.util.ArrayList;
import java.util.List;

public class modelo {

    private List<Producto> carrito = new ArrayList<>();
    private final List<Producto> productos;
    private final List<String> categorias;

    public modelo() {

        productos = new ArrayList<>();
        categorias = new ArrayList<>();

        cargarCategorias();
        // Categoría: Limpieza

        agregarProducto("Jabón Zote", "Limpieza", 18.50, "/Tienda/imagenes/Zote.png");
        agregarProducto("Detergente Liquid", "Limpieza", 45.00, "/Tienda/imagenes/detergente.png");
        agregarProducto("Cloro", "Limpieza", 22.50, "/Tienda/imagenes/cloro.png");
        agregarProducto("Fabuloso", "Limpieza", 33.70, "/Tienda/imagenes/f.png");
        agregarProducto("Pinol", "Limpieza", 38.50, "/Tienda/imagenes/p.png");
        agregarProducto("Limpiador para Vidrios", "Limpieza", 42.00, "/Tienda/imagenes/v.png");
        agregarProducto("Ariel", "Limpieza", 47.90, "/Tienda/imagenes/A.png");
        agregarProducto("Cuidado Superior Flor de Primavera", "Limpieza", 74.50, "/Tienda/imagenes/S.png");
        agregarProducto("Limpia tu Inodoro con Harpic", "Limpieza", 49.00, "/Tienda/imagenes/H.png");
        agregarProducto("Pato Pastilla Desinfectante", "Limpieza", 28.00, "/Tienda/imagenes/pp.png");
        agregarProducto("Roma Detergente", "Limpieza", 33.70, "/Tienda/imagenes/R.png");
        agregarProducto("Desinfectante en Aerosol", "Limpieza", 85.00, "/Tienda/imagenes/D.png");
        
        // Categoría: Alimentos
        agregarProducto("Verde Valle Arroz Súper Extra", "Alimentos", 28.00, "/Tienda/imagenes/Arroz.png");
        agregarProducto("Nescafe Café Soluble ", "Alimentos", 175.00, "/Tienda/imagenes/nes.png");
        agregarProducto("Cereal Integral Nestlé ", "Alimentos", 64.40, "/Tienda/imagenes/cer.png");
        agregarProducto("La Lechera Nestlé ", "Alimentos", 24.60, "/Tienda/imagenes/lec.png");
        agregarProducto("Verde Valle Queretaro Frijol Negro", "Alimentos", 42.90, "/Tienda/imagenes/vaññ.png");
        agregarProducto("Caldo de Pollo Knorr", "Alimentos", 20.35, "/Tienda/imagenes/cual.png");
        agregarProducto("Samyang Buldak Ramen Picante ", "Alimentos", 58.00, "/Tienda/imagenes/ram.png");
        agregarProducto(" Aceite Comestible Vegetal ", "Alimentos", 33.60, "/Tienda/imagenes/ace.png");
        agregarProducto("Yoplait Yogurth Batido Sabor Fresa", "Alimentos", 61.35, "/Tienda/imagenes/yo.png");
        agregarProducto("Leche Lala Entera ", "Alimentos", 23.00, "/Tienda/imagenes/leee.png");
        agregarProducto(" Tomates Molidos ", "Alimentos", 8.00, "/Tienda/imagenes/tom.png");
        agregarProducto("Yemina Pasta Spaghetti ", "Alimentos", 8.00, "/Tienda/imagenes/sp.png");
        
    
        // Categoría: Bebidas
        agregarProducto("Agua 1L", "Bebidas", 15.00, "/Tienda/imagenes/c.png");
        agregarProducto("Powerade Ion4", "Bebidas", 20.00, "/Tienda/imagenes/pow.png");
        agregarProducto("Fuze Tea", "Bebidas", 20.90, "/Tienda/imagenes/te.png");
        agregarProducto("Jumex Prisma Mango", "Bebidas", 25.90, "/Tienda/imagenes/ma.png");
        agregarProducto("Flashlyte Suero", "Bebidas", 20.00, "/Tienda/imagenes/fl.png");
        agregarProducto("Energética Monster Energy", "Bebidas", 41.50, "/Tienda/imagenes/mos.png");
        agregarProducto("Refresco Coca-Cola", "Bebidas", 20.00, "/Tienda/imagenes/co.png");
        agregarProducto("Pepsi Regular", "Bebidas", 18.90, "/Tienda/imagenes/pes.png");
        agregarProducto("Rehidratante Electrolit Uva", "Bebidas", 33.00, "/Tienda/imagenes/ele.png");
        agregarProducto("Jugo Del Valle", "Bebidas", 26.00, "/Tienda/imagenes/ju.png");
        agregarProducto("Lotte Soju Chum Churum", "Bebidas", 77.90, "/Tienda/imagenes/k.png");
        agregarProducto("Refresco Sabor Lima-Limón", "Bebidas", 26.00, "/Tienda/imagenes/lll.png");
        
        // Categoría: Golosinas
        agregarProducto("Takis Fuego Botana", "Golosinas", 20.00, "/Tienda/imagenes/tak.png");
        agregarProducto("Panditas, Gomitas de sabores frutales", "Golosinas", 19.00, "/Tienda/imagenes/go.png");
        agregarProducto("Kinder Delice", "Golosinas", 14.00, "/Tienda/imagenes/ch.png");
        agregarProducto("Donas de Azúcar Bimbo ", "Golosinas", 25.90, "/Tienda/imagenes/bon.png");
        agregarProducto("Picafresa gigante, Gomita", "Golosinas", 110.70, "/Tienda/imagenes/gi.png");
        agregarProducto("Arcoiris Sabor a Fresa", "Golosinas", 42.00, "/Tienda/imagenes/arco.png");
        agregarProducto("Chips Ahoy!", "Golosinas", 30.50, "/Tienda/imagenes/gomi.png");
        agregarProducto("M&Ms Chocolate Chocolate", "Golosinas", 20.00, "/Tienda/imagenes/mg.png");
        agregarProducto("Skittles Confites ", "Golosinas", 25.10, "/Tienda/imagenes/sk.png");
        agregarProducto("Sonric's Rockaleta Bola", "Golosinas", 82.00, "/Tienda/imagenes/rok.png");
        agregarProducto("Pastillas refrescantes Tic Tac Menta", "Golosinas", 13.80, "/Tienda/imagenes/tic.png");
        agregarProducto("Betalina", "Golosinas", 25.00, "/Tienda/imagenes/betalina.png");
    } 

    private void cargarCategorias() {

        categorias.add("Limpieza");
        categorias.add("Alimentos");
        categorias.add("Golosinas");
        categorias.add("Bebidas");
    }

    public void agregarAlCarrito(Producto p) {
        carrito.add(p);
    }

    public List<Producto> obtenerCarrito() {
        return new ArrayList<>(carrito);
    }

    public List<String> obtenerCategorias() {
        return new ArrayList<>(categorias);
    }

    public List<Producto> obtenerProductos() {
        return new ArrayList<>(productos);
    }

    public void agregarProducto(String nombre, String categoria,
            double precio, String rutaImagen) {

        Producto producto = new Producto(
                nombre,
                categoria,
                precio,
                rutaImagen
        );

        productos.add(producto);
    }

    public List<Producto> filtrarProductos(String categoria,
            String textoBusqueda) {

        List<Producto> resultado = new ArrayList<>();

        String categoriaFiltro =
                (categoria == null) ? "Todos" : categoria.trim();

        String texto =
                (textoBusqueda == null)
                ? ""
                : textoBusqueda.trim().toLowerCase();

        for (Producto producto : productos) {

            boolean coincideCategoria =
                    categoriaFiltro.equalsIgnoreCase("Todos")
                    || producto.getCategoria()
                            .equalsIgnoreCase(categoriaFiltro);

            boolean coincideBusqueda =
                    texto.isEmpty()
                    || producto.getNombre()
                            .toLowerCase()
                            .contains(texto)
                    || producto.getCategoria()
                            .toLowerCase()
                            .contains(texto);

            if (coincideCategoria && coincideBusqueda) {
                resultado.add(producto);
            }
        }

        return resultado;
    }

    public List<Producto> filtrarPorCategoria(String categoria) {

        List<Producto> resultado = new ArrayList<>();

        if (categoria == null
                || categoria.equalsIgnoreCase("Todos")) {

            return obtenerProductos();
        }

        for (Producto producto : productos) {

            if (producto.getCategoria()
                    .equalsIgnoreCase(categoria)) {

                resultado.add(producto);
            }
        }

        return resultado;
    }

    public void eliminarProducto(String nombre) {

        productos.removeIf(
                producto -> producto.getNombre()
                        .equalsIgnoreCase(nombre)
        );
    }

    public void limpiarProductos() {
        productos.clear();
    }
}