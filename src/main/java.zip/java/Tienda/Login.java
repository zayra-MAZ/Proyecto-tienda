/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tienda;


import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Login extends JFrame {

    private JTextField txtUsuario;
    private JTextField txtEmail;
    private JPasswordField txtPassword;

    public Login() {

        setTitle("Iniciar sesión");
        setSize(350, 580);
        setIconImage(new ImageIcon(getClass().getResource("")).getImage());
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);
        setLayout(null);


        getContentPane().setBackground(new Color(245, 247, 250));

        JLabel titulo = new JLabel("Iniciar sesión");
        titulo.setFont(new Font("SansSerif", Font.BOLD, 22));
        titulo.setForeground(new Color(45, 45, 45));
        titulo.setBounds(90, 20, 200, 30);
        add(titulo);


        ImageIcon icono = new ImageIcon("C:\\Users\\linda\\Downloads\\osito.png");

        Image imagenEscalada = icono.getImage().getScaledInstance(
                130,
                130,
                Image.SCALE_SMOOTH
        );

        JLabel lblImagen = new JLabel(new ImageIcon(imagenEscalada));
        lblImagen.setBounds(105, 60, 130, 130);
        add(lblImagen);


        JLabel lblUsuario = new JLabel("Usuario");
        lblUsuario.setFont(new Font("SansSerif", Font.BOLD, 13));
        lblUsuario.setForeground(new Color(70, 70, 70));
        lblUsuario.setBounds(40, 210, 260, 20);
        add(lblUsuario);

        txtUsuario = new JTextField();
        txtUsuario.setBounds(40, 235, 260, 35);
        txtUsuario.setFont(new Font("SansSerif", Font.PLAIN, 14));
        txtUsuario.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200), 2));
        add(txtUsuario);

        JLabel lblEmail = new JLabel("Correo electrónico");
        lblEmail.setFont(new Font("SansSerif", Font.BOLD, 13));
        lblEmail.setForeground(new Color(70, 70, 70));
        lblEmail.setBounds(40, 285, 260, 20);
        add(lblEmail);

        txtEmail = new JTextField();
        txtEmail.setBounds(40, 310, 260, 35);
        txtEmail.setFont(new Font("SansSerif", Font.PLAIN, 14));
        txtEmail.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200), 2));
        add(txtEmail);


        JLabel lblPassword = new JLabel("Contraseña");
        lblPassword.setFont(new Font("SansSerif", Font.BOLD, 13));
        lblPassword.setForeground(new Color(70, 70, 70));
        lblPassword.setBounds(40, 360, 260, 20);
        add(lblPassword);

        txtPassword = new JPasswordField();
        txtPassword.setBounds(40, 385, 260, 35);
        txtPassword.setFont(new Font("SansSerif", Font.PLAIN, 14));
        txtPassword.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200), 2));
        add(txtPassword);

        JButton btnEntrar = new JButton("Entrar");
        btnEntrar.setBounds(40, 440, 260, 38);
        btnEntrar.setBackground(new Color(52, 152, 219));
        btnEntrar.setForeground(Color.WHITE);
        btnEntrar.setFocusPainted(false);
        btnEntrar.setFont(new Font("SansSerif", Font.BOLD, 14));
        btnEntrar.setBorder(BorderFactory.createEmptyBorder());
        add(btnEntrar);

        JButton btnRegistrar = new JButton("Crear cuenta");
        btnRegistrar.setBounds(40, 485, 260, 38);
        btnRegistrar.setBackground(new Color(46, 204, 113));
        btnRegistrar.setForeground(Color.WHITE);
        btnRegistrar.setFocusPainted(false);
        btnRegistrar.setFont(new Font("SansSerif", Font.BOLD, 14));
        btnRegistrar.setBorder(BorderFactory.createEmptyBorder());
        add(btnRegistrar);


        btnEntrar.addActionListener(e -> {

            String user = txtUsuario.getText();
            String email = txtEmail.getText();
            String pass = new String(txtPassword.getPassword());

            if (user.isEmpty() || email.isEmpty() || pass.isEmpty()) {

                JOptionPane.showMessageDialog(this, "Complete");

            } else {

                validarAcceso(user, email, pass);
            }
        });
    }

    private void validarAcceso(String user, String email, String password) {

        String sql = "SELECT * FROM usuarios WHERE usuario = ? AND email = ? AND contrasena = ?";

        try (
                Connection con = Conexion.conectar();
                PreparedStatement pst = con.prepareStatement(sql)
        ) {

            pst.setString(1, user);
            pst.setString(2, email);
            pst.setString(3, password);

            ResultSet rs = pst.executeQuery();

            if (rs.next()) {

                JOptionPane.showMessageDialog(this, "Bienvenido");

            } else {

                JOptionPane.showMessageDialog(
                        this,
                        "Incorrecto",
                        "Error",
                        JOptionPane.ERROR_MESSAGE
                );
            }

        } catch (SQLException ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "Error: " + ex.getMessage()
            );
        }
    }

    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> new Login().setVisible(true));
    }
}